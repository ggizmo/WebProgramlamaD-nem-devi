﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Web_Prog_Proje.Models
{
    public class Karakter
    {
        public int Id { get; set; }
        [Required]
        public string Ad { get; set; }
        public string Soyad { get; set; }

        public int? UlkeId { get; set; }
        public Ulke Ulke { get; set; }
        public string AdSoyad { get { return Ad + " " + Soyad; } }
    }
}
